/*
 * Tempo Titans - Display + Audio
 * 
 * Display Wiring:
 *   AV+ (Yellow) -> GPIO 25  (Video signal)
 *   GND (Black)  -> GND
 *   5V (Red)     -> 5V
 * 
 * MAX98357A Wiring:
 *   Vin  -> 5V
 *   GND  -> GND
 *   BCLK -> GPIO 14  (Bit Clock - timing signal for each audio bit)
 *   LRC  -> GPIO 13  (Left/Right Clock - separates left and right audio channels)
 *   DIN  -> GPIO 27  (Data In - the actual audio data)
 */

#include "ESP_8_BIT_GFX.h"
#include "driver/i2s.h"

// Video output: NTSC mode, 8-bit colour
ESP_8_BIT_GFX videoOut(true, 8);

// I2S audio pins
#define I2S_BCLK 14
#define I2S_LRC  13
#define I2S_DOUT 27

// Audio settings
#define SAMPLE_RATE 16000

// BPM and timing
int bpm = 50;
int beatCount = 0;
unsigned long lastBeatTime = 0;

// Colours (colour-blind friendly)
uint8_t bgColor = 0x02;        // Dark blue background
uint8_t boxColor = 0x03;       // Blue boxes (inactive)
uint8_t activeColor = 0xFC;    // Yellow (active)
uint8_t textColor = 0xFF;      // White text

void setupI2S() {
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 64,
    .use_apll = false,
    .tx_desc_auto_clear = true
  };
  
  i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_BCLK,
    .ws_io_num = I2S_LRC,
    .data_out_num = I2S_DOUT,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  
  // Use I2S_NUM_1 instead of I2S_NUM_0 (video uses I2S_NUM_0)
  i2s_driver_install(I2S_NUM_1, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_NUM_1, &pin_config);
}

void playClick(bool accent) {
  int frequency = accent ? 1500 : 1000;
  float volume = accent ? 0.8 : 0.5;
  int durationMs = 30;
  int samples = SAMPLE_RATE * durationMs / 1000;
  size_t bytesWritten;
  
  for (int i = 0; i < samples; i++) {
    float envelope = 1.0 - ((float)i / samples);
    float angle = 2.0 * PI * frequency * i / SAMPLE_RATE;
    int16_t sample = (int16_t)(sin(angle) * envelope * volume * 32000);
    
    int16_t stereo[2] = {sample, sample};
    i2s_write(I2S_NUM_1, stereo, sizeof(stereo), &bytesWritten, portMAX_DELAY);
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("Tempo Titans - Display + Audio");
  
  // Initialize video FIRST
  videoOut.begin();
  videoOut.copyAfterSwap = true;
  
  // Initialize audio on I2S_NUM_1
  setupI2S();
  
  // Startup beep
  playClick(true);
  
  Serial.println("Ready!");
}

void loop() {
  videoOut.waitForFrame();
  videoOut.fillScreen(bgColor);
  
  // Current beat (0-3)
  int currentBeat = (beatCount % 4);
  
  // Beat box dimensions
  int boxWidth = 50;
  int boxHeight = 60;
  int boxSpacing = 10;
  int startX = 13;
  int boxY = 30;
  
  // Draw 4 beat boxes
  for (int i = 0; i < 4; i++) {
    int x = startX + (i * (boxWidth + boxSpacing));
    
    if (i == currentBeat) {
      videoOut.fillRect(x, boxY, boxWidth, boxHeight, activeColor);
      videoOut.setTextColor(0x00);
    } else {
      videoOut.fillRect(x, boxY, boxWidth, boxHeight, boxColor);
      videoOut.setTextColor(0xFF);
    }
    
    videoOut.setTextSize(2);
    videoOut.setCursor(x + 18, boxY + 22);
    videoOut.print(i + 1);
  }
  
  // Draw BPM display
  videoOut.setTextColor(textColor);
  videoOut.setTextSize(2);
  videoOut.setCursor(50, 110);
  videoOut.print("Current BPM:");
  
  videoOut.setTextSize(4);
  if (bpm < 100) {
    videoOut.setCursor(95, 145);
  } else {
    videoOut.setCursor(75, 145);
  }
  videoOut.print(bpm);
  
  // Beat timing
  unsigned long beatInterval = 60000 / bpm;
  
  if (millis() - lastBeatTime >= beatInterval) {
    lastBeatTime = millis();
    beatCount++;
    
    // Play click - accent on beat 1
    bool isAccent = ((beatCount % 4) == 1);
    playClick(isAccent);
    
    Serial.print("Beat: ");
    Serial.println((beatCount % 4) + 1);
  }
}