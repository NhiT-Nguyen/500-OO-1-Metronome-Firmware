/*
 * Tempo Titans - Audio Test
 * 
 * MAX98357A Wiring:
 *   Vin  -> 5V
 *   GND  -> GND
 *   BCLK -> GPIO 14  (Bit Clock - timing signal for each audio bit)
 *   LRC  -> GPIO 13  (Left/Right Clock - separates left and right audio channels)
 *   DIN  -> GPIO 27  (Data In - the actual audio data)
 */

#include "driver/i2s.h"

// I2S pins
#define I2S_BCLK 14
#define I2S_LRC  13
#define I2S_DOUT 27

// Audio settings
#define SAMPLE_RATE 16000

void setup() {
  Serial.begin(115200);
  Serial.println("Audio Test - MAX98357A");
  
  // I2S configuration
  i2s_config_t i2s_config = {
    .mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX),
    .sample_rate = SAMPLE_RATE,
    .bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT,
    .channel_format = I2S_CHANNEL_FMT_RIGHT_LEFT,
    .communication_format = I2S_COMM_FORMAT_STAND_I2S,
    .intr_alloc_flags = ESP_INTR_FLAG_LEVEL1,
    .dma_buf_count = 8,
    .dma_buf_len = 64,
    .use_apll = false,
    .tx_desc_auto_clear = true
  };
  
  // I2S pin configuration
  i2s_pin_config_t pin_config = {
    .bck_io_num = I2S_BCLK,
    .ws_io_num = I2S_LRC,
    .data_out_num = I2S_DOUT,
    .data_in_num = I2S_PIN_NO_CHANGE
  };
  
  // Install I2S driver
  i2s_driver_install(I2S_NUM_0, &i2s_config, 0, NULL);
  i2s_set_pin(I2S_NUM_0, &pin_config);
  
  Serial.println("Playing test beeps...");
  
  // Play 3 test beeps
  for (int i = 0; i < 3; i++) {
    playTone(1000, 100);  // 1000Hz for 100ms
    delay(300);
  }
  
  Serial.println("Done!");
}

void playTone(int frequency, int durationMs) {
  int samples = SAMPLE_RATE * durationMs / 1000;
  int16_t sample;
  size_t bytesWritten;
  
  for (int i = 0; i < samples; i++) {
    // Generate sine wave
    float angle = 2.0 * PI * frequency * i / SAMPLE_RATE;
    sample = (int16_t)(sin(angle) * 16000);
    
    // Stereo: write same sample to left and right
    int16_t stereo[2] = {sample, sample};
    i2s_write(I2S_NUM_0, stereo, sizeof(stereo), &bytesWritten, portMAX_DELAY);
  }
}

void loop() {
  // Nothing here - just testing in setup
}