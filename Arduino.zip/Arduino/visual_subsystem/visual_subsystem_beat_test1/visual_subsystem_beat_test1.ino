/*
 * Tempo Titans - BPM Display Test
 * Shows BPM with a flashing beat indicator
 */

#include "ESP_8_BIT_GFX.h"

// PAL = false (~25fps), NTSC = true(~30fps/60Hx) - (Analog TV standards)
ESP_8_BIT_GFX videoOut(true, 8);

int bpm = 120;
int beatCount = 0;
bool beatOn = false;
unsigned long lastBeatTime = 0;

void setup() {
  Serial.begin(115200);
  Serial.println("Tempo Titans - BPM Test");
  
  videoOut.begin();
  videoOut.copyAfterSwap = true;
  
  Serial.println("Ready!");
}

void loop() {
  videoOut.waitForFrame();
  videoOut.fillScreen(0x1F);  // Cyan background
  
  // === TITLE ===
  videoOut.setTextColor(0x03);  // Green
  videoOut.setTextSize(2);
  videoOut.setCursor(30, 10);
  videoOut.print("TEMPO TITANS");
  
  // === BPM DISPLAY ===
  videoOut.setTextColor(0x03);  // Blue
  videoOut.setTextSize(2);
  videoOut.setCursor(100, 50);
  videoOut.print("BPM");
  
  videoOut.setTextSize(4);
  videoOut.setCursor(85, 80);
  videoOut.print(bpm);
  
  // === BEAT INDICATOR ===
  unsigned long beatInterval = 60000 / bpm;  // Milliseconds per beat
  
  if (millis() - lastBeatTime >= beatInterval) {
    lastBeatTime = millis();
    beatOn = true;
    beatCount++;
    Serial.println("BEAT!");
  }
  
  // Beat stays on for 100ms
  if (millis() - lastBeatTime > 100) {
    beatOn = false;
  }
  
  // Draw beat circle
  if (beatOn) {
    videoOut.fillCircle(128, 160, 25, 0xE0);  // Red filled
  } else {
    videoOut.drawCircle(128, 160, 25, 0x03);  // Blue outline
  }
  
  // === BEAT COUNT (1-2-3-4) ===
  videoOut.setTextColor(0xFC);  // Yellow
  videoOut.setTextSize(3);
  videoOut.setCursor(118, 200);
  int currentBeat = ((beatCount - 1) % 4) + 1;
  videoOut.print(currentBeat);
  
  // === BEAT BAR ===
  // Visual bar showing all 4 beats
  for (int i = 0; i < 4; i++) {
    int x = 50 + (i * 45);
    if (i == (beatCount - 1) % 4) {
      videoOut.fillRect(x, 225, 35, 10, 0xE0);  // Red = current beat
    } else {
      videoOut.drawRect(x, 225, 35, 10, 0xFF);  // White outline
    }
  }
}