/*
* Tempo Titans - Visual Subsystem
  Claude 
*/


#include "ESP_8_BIT_GFX.h"

ESP_8_BIT_GFX videoOut(true, 8);

void setup() {
  Serial.begin(115200);
  Serial.println("Tempo Titans Display Test");
  
  videoOut.begin();
  videoOut.copyAfterSwap = true;
  
  Serial.println("Video initialized!");
}

void loop() {
  videoOut.waitForFrame();
  videoOut.fillScreen(0x00);
  
  // Title
  videoOut.setTextColor(0xFF);
  videoOut.setTextSize(2);
  videoOut.setCursor(30, 30);
  videoOut.print("TEMPO TITANS");
  
  // Hello World
  videoOut.setTextSize(3);
  videoOut.setCursor(35, 100);
  videoOut.print("Hello World");
  
  // Colored circles
  videoOut.fillCircle(64, 200, 15, 0xE0);   // Red
  videoOut.fillCircle(128, 200, 15, 0x1C);  // Green
  videoOut.fillCircle(192, 200, 15, 0x03);  // Blue
}